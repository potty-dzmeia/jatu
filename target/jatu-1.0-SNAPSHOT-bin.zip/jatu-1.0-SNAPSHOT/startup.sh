#!/bin/sh

java -classpath "jatu-1.0-SNAPSHOT.jar:./pyrig" org.lz1aq.jatu.Main