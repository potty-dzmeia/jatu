import misc_utils

# aa = dict()
# aa["dfd"] = 1
# print  aa.__len__()
#
# my_list = [1, 2, 3, 4]
# my_byte_array = bytearray(my_list)
#
# print misc_utils.getListInHex(my_byte_array)

print '{: <24}'.format('11111112222222222')